<!-- <?php 

?>

<div class="header">
  <h1>CARE AND CURE</h1>
  <p>This website created by me.</p>
</div>

<div class="row">
  <div class="side">
    <h2>About Me</h2>
    <h5>Photo of me:</h5>
    <div class="fakeimg" style="height:200px;">Image</div>
    <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
    <h3>More Text</h3>
    <p>Lorem ipsum dolor sit ame.</p>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div>
  </div>

  <div class="main">
    <h2>TITLE HEADING</h2>
    <h5>Title description, sep 7, 2019</h5>
    <div class="fakeimg" style="height:200px;">Image</div>
    <p>Some text..</p>
    <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
    <br>
  </div>
</div>

<div class="row">
  <div class="column">
    <img src="image/1.jpg" style="width:100%">
    <a>text</a>
  </div>
  <div class="column">
    <img src="image/1.jpg" style="width:100%">
    <a>text</a>
  </div>
  <div class="column">
    <img src="image/1.jpg" style="width:100%">
    <a>text</a>
  </div>
</div>

<div class="footer">
  <h2>THANK YOU VISIT AGAIN</h2>
</div>

</body>
</html> -->

<?php 
include('header2.php');
?>

<div class="header">
  <h1>CARE AND CURE</h1>
  <p>This website created by group " C "</p>
</div>

<div class="row">
  <div class="side">
    <h2>Photo of me:</h2>
    <p></p>
    <div class="fakeimg" style="height:200px;"></div>
    <h2>This company provides serves over 10 years.</h2>
    <h1><font color="red">SCHEDULE 'H' DRUG</font></h1>
  </div>

  <div class="main">
    <h2>Medicine Helpers</h2>
    <div class="fakeimg1" style="height:200px;"></div>
    <h4>Title Description Upload On : September 7, 2019</h4>
    <P>AFTER BUYING PLEASE KEEP ALL MEDICINE IN A COOL AND DRY PLACE</P>
    <h3><font color="red">WARNING : TO BE SOLD BY RETAIL ON THE PRESCRIPTION OF A REGISTERED MEDICAL PRACTITIONER ONLY.</font></h3>
    <br>
  </div>
</div>

<div class="row">
  <div class="column">
    <img src="image/Baby.jpg" style="width:50%">
  </div>
  <div class="column">
    <img src="image/Vitamin.jpg" style="width:50%">
    <h4>This is demo, For buy please go 'medicine & cart' part</h4>
  </div>
  <div class="column">
    <img src="image/powder.jpg" style="width:50%">
  </div>
</div>

<div class="footer">
  <h2>THANK YOU VISIT AGAIN</h2>
</div>

</body>
</html>