<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		.arindam {

			background-color: lightblue;

		}
	</style>
</head>
<body>
	<div class="arindam">
		<h1 align="center">Thank you</h1>
		<h4 align="center"><a href="index2.php">Go To Home</a></h4>
	</div>

</body>
</html>