<!DOCTYPE html>
<html>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amatic+SC">
<style>
body, html {height: 100%}
body,h1,h2,h3,h4,h5,h6 {font-family: "Microsoft Sans Serif"}
.menu {display: none}
.bgimg {
  background-repeat: repeat;
  background-size: cover;
  background-image: url("m.jpg");
  min-height: 100%;
}
.imgcontainer {
  text-align: center;
  margin: 50px 0 60px 0;
}
img.avatar {
  width: 40%;
  border-radius: 40%;
}
</style>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top w3-hide-small">
  <div class="w3-bar w3-xlarge w3-black w3-opacity w3-hover-opacity-off" id="myNavbar">
    <a href="#" class="w3-bar-item w3-button">HOME</a>
    <a href="#menu" class="w3-bar-item w3-button">MENU</a>
    <a href="#about" class="w3-bar-item w3-button">ABOUT</a>
    <a href="#contact" class="w3-bar-item w3-button">CONTACT</a>
    <a href="#signup" class="w3-bar-item w3-button">SIGNUP</a>
    <a href="#login" class="w3-bar-item w3-button">LOGIN</a>
  </div>
</div>
  
<!-- Header with image -->
<header class="bgimg w3-display-container" id="home">
  <div class="w3-display-bottommiddle w3-padding">
    <marquee><span class="w3-tag w3-xlarge" style="font-size:50px">WELCOME - TO - PIZZA - SHOP</span></marquee>
  </div>

  <div class="w3-display-middle w3-center">
    <div class="w3-display-upright w3-padding">
    <marquee><span class="w3-tag w3-xlarge" style="font-size:50px">WEBSITE DEVOLOPED BY - ARINDAM SAHA</span></marquee>
  </div>
    <span class="w3-text-black w3-hide-small" style="font-size:70px"><br>PIZZA CLUB</span>
    <span class="w3-text-white w3-hide-large w3-hide-medium" style="font-size:20px"><b><br>PIZZA CLUB</b></span>
    <p><a href="#menu" class="w3-button w3-xxlarge w3-black">Let see the menu</a></p>
  </div>
</header>

<!-- Menu Container -->
<div class="w3-container w3-black w3-padding-64 w3-xxlarge" id="menu">
  <div class="w3-content">
  
    <h1 class="w3-center w3-jumbo" style="margin-bottom:64px">THE MENU</h1>
    <div class="w3-row w3-center w3-border w3-border-dark-grey">
      <a href="javascript:void(0)" onclick="openMenu(event, 'Veg Pizza');" id="myLink">
        <div class="w3-col s4 tablink w3-padding-large w3-hover-red">Veg Pizza</div>
      </a>
      <a href="javascript:void(0)" onclick="openMenu(event, 'Chicken Pizza');">
        <div class="w3-col s4 tablink w3-padding-large w3-hover-red">Chicken Pizza</div>
      </a>
      <a href="javascript:void(0)" onclick="openMenu(event, 'Starter');">
        <div class="w3-col s4 tablink w3-padding-large w3-hover-red">Starter</div>
      </a>
    </div>

    <div id="Veg Pizza" class="w3-container menu w3-padding-32 w3-white">
      <h1><b>Margherita <img src="mg.jpg" alt="Avatar" class="avatar" style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.100/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"> <span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Fresh tomatoes, fresh mozzarella, fresh basil</p>                                                
      <hr>
   
      <h1><b>Farm house      <img src="fh.png" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.99/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">cheeses, tomato, vegitables</p>
      <hr>
      
      <h1><b>Perry Paneer  <img src="pp.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.110/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Fresh tomatoes, mozzarella, paneer, onions</p>
      <hr>

      <h1><b>Mexican green  <img src="mgr.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.90/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Fresh tomatoes, fresh green vegatable, bacon, fresh basil</p>
      <hr>

      <h1><b>Deluxe veg <img src="dv.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%">  </b> <span class="w3-tag w3-red w3-round">Hot!</span><span class="w3-right w3-tag w3-dark-grey w3-round">Rs.130/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Fresh tomatoes, mozzarel, hot pepporoni, hot sausage,cheeses</p>
      <hr>

      <h1><b>Cheese n corn  <img src="cc.png" align="w3-display-middle" alt="Avatar" class="avatar"style="width:30%; height:30%"></b><span class="w3-right w3-tag w3-dark-grey w3-round">Rs.99/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Fresh tomatoes, mozzarella, parma, bacon</p>
    </div>

    <div id="Chicken Pizza" class="w3-container menu w3-padding-32 w3-white">
      <h1><b>Pepper Chicken</b> <img src="pb.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"> </b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.150/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <h2><span class="w3-tag w3-grey w3-round">Popular</span></h2>
      <p class="w3-text-grey">Special sauce, mozzarella, parmesan, ground chicken</p>
      <hr>
   
      <h1><b>Chicken Sausage</b> <img src="cs.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.150/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Ravioli filled with cheese</p>
      <hr>
      
      <h1><b>Golden Delight</b> <img src="gd.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.130/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Fresh tomatoes, onions, ground chicken</p>
      <hr>

      <h1><b>Chicken Fiesta</b> <img src="cf.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.140/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Salmon, shrimp, lobster, garlic</p>
    </div>


    <div id="Starter" class="w3-container menu w3-padding-32 w3-white">
      <h1><b>Today's Soup</b> <img src="so.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.50/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <h2><span class="w3-tag w3-grey w3-round">Seasonal</span></h2>
      <p class="w3-text-grey">Ask the waiter</p>
      <hr>
   
      <h1><b>Bruschetta</b> <img src="br.jpg" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.40/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Bread with pesto, tomatoes, onion, garlic</p>
      <hr>
      
      <h1><b>Garlic bread</b> <img src="gb.webp" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.60/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Grilled ciabatta, garlic butter, onions</p>
      <hr>
      
      <h1><b>Tomozzarella</b> <img src="mm.webp" alt="Avatar" class="avatar"style="width:30%; height:30%"></b> <span class="w3-right w3-tag w3-dark-grey w3-round">Rs.50/-</span><a href="checkout.html" onclick="Opening(event, 'BUY IT');"><span class="w3-right w3-tag w3-green w3-round">BUY IT</span></a></h1>
      <p class="w3-text-grey">Tomatoes and mozzarella</p>
    </div><br>

  </div>
</div>

<!-- About Container -->
<div class="w3-container w3-padding-64 w3-red w3-xlarge" id="about">
  <div class="w3-content">
    <h1 class="w3-center w3-jumbo" style="margin-bottom:64px">About Us</h1>
    <p>The Pizza Restaurant was founded in chuchura by club group in lorem ipsum rupay sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
    <!--<p><strong>The Chef?</strong> Mr. Italiano himself
    <img src="/w3images/chef.jpg" style="width:150px" class="w3-circle w3-right" alt="Chef"></p>
    <p>We are proud of our interiors.</p>-->
    <img src="res.jpg" style="width:80%" class="w3-margin-top w3-margin-bottom" alt="Restaurant">
    <h1><b><span class="w3-tag">Opening Hours</span></b></h1>
    
    <div class="w3-row">
      <div class="w3-col s6">
        <p>Mon & Tue CLOSED</p>
        <p>Wednesday 10.00 - 24.00</p>
        <p>Thursday 10:00 - 24:00</p>
      </div>
      <div class="w3-col s6">
        <p>Friday 10:00 - 12:00</p>
        <p>Saturday 10:00 - 23:00</p>
        <p>Sunday Closed</p>
      </div>
    </div>
    
  </div>
</div>

<script>
// Tabbed Menu
function openMenu(evt, menuName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("menu");
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
     tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(menuName).style.display = "block";
  evt.currentTarget.firstElementChild.className += " w3-red";
}
document.getElementById("myLink").click();
</script>

<!-- signup -->
<div class="w3-container w3-padding-64 w3-yellow w3-xlarge" id="signup">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 25px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>

<!--<form action="/action_page.php" style="border:1px solid #ccc">-->
  <div class="container">
    <h1>Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
    
    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>
    
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
  </div>
</form>
</div>

<!-- login -->
<div class="w3-padding-64 w3-blue w3-xlarge" id="login">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: red;
}

.imgcontainer {
  text-align: center;
  margin: 12px 0 12px 0;
}

img.avatar {
  width: 10%;
  border-radius: 50%;
}

.container {
  padding: 25px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>

<h2>Login Form</h2>

<form action="/action_page.php">
  <div class="imgcontainer">
    <img src="cfff.jpg" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
        
    <button type="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:white">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw"><a href="#">forget password?</a></span>
  </div>
</form>
</div>

</body>
</html>