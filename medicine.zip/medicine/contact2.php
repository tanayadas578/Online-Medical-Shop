<!-- <?php 

?>

<div class="w3-container w3-padding-64 w3-blue w3-grayscale-min w3-xlarge" id="contact">
  <div class="w3-content">
    <h1 class="w3-center w3-jumbo" style="margin-bottom:64px">Contact</h1>
    <p>Find us at some address at some place or call us at 12345-12456</p>
    <p><span class="w3-tag">FYI !!</span> We offer full-service catering for any event, large or small. We understand your needs and we will cater the food to satisfy the biggerst criteria of them all, both look and taste.</p>
    <p class="w3-xxlarge"><strong>Reserve</strong> a table, ask for today's special just send us a message or call:</p>
    <p><span class="w3-tag">Phone : 12345-12456</span></p>
    <p><span class="w3-tag">Email : pizzaclub09@gmail.com</span></p>
    <p>You can also fellow our facebook or instagram page for farther details</p>
    <p><span class="w3-tag">facebook : Pizza_Club</span></p>
    <p><span class="w3-tag">instagram : Pizza_Club09</span></p>
      </div>
</div>
 -->

<?php 
include('header2.php');
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* Style the container/contact section */
.container {
  border-radius: 5px;
  background-color: cyan;
  padding: 10px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>

<!-- <h2>Responsive Contact Section</h2>
<p>Resize the browser window to see the effect.</p> -->

<div class="container">
  <div style="text-align:center">
    <h1>Contact Us</h1>
<!--     <p>Swing by for a cup of coffee, or leave us a message:</p>
 -->  </div>
  <div class="row">
    <div class="column">
      <img src="image/medication.jpg" style="width:100%">
    </div>
    <div class="column">
      <form action="contact.php">
        <label for="fname">First Name</label>
        <input type="text" id="fname" name="firstname" placeholder="Your name..">
        <label for="lname">Last Name</label>
        <input type="text" id="lname" name="lastname" placeholder="Your last name..">
        <label for="country">Country</label>
        <select id="country" name="country">
            <option value="india">India</option>
          <option value="australia">Australia</option>
          <option value="usa">USA</option>
        </select>
        <label for="subject">Subject</label>
        <textarea id="subject" name="subject" placeholder="Write something.." style="height:150px"></textarea>
        <input type="submit" value="Submit">
      </form>
    </div>
  </div>
</div>

</body>
</html>
