 <?php
// include('action.php');
include('./config/head_class.php');
$data_array=array("table"=>"user_tbl");
array_push($data_array,$_POST);
print_r($data_array);
//die();
$obj=new Important;
$i=$obj->insert_data($data_array);
if($i==1){
	echo "Data Inserted";
}else{
	echo "Error! In data save";
}

?>