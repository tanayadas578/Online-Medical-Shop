<?php
session_start();
include('./config/head_class.php');
$obj=new Important;
$data=array("table"=>"user_tbl");
array_push($data,$_POST);
$n=$obj->login_check($data);
$rs=mysqli_fetch_array($n);
if($rs){
	$_SESSION['admin']=$_POST['email'];
	$_SESSION['is_login']="true";
?>
	<script type="text/javascript">
		alert("Login Successfull");
		window.location.href='Index2.php';
	</script>
<?php
}
else{
	?>
	<script type="text/javascript">
		alert("Invalid Username or Password");
		window.location.href='userlog.html';
	</script>
<?php
}
?>