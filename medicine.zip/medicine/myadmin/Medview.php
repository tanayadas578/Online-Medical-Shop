<?php 
include('adminheader.php');
?>
<?php include('head_class.php');?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
		<style>
		.form-cover{
	margin: 10;
	width: 50%;
	border: 10px;
	border-radius: 10px;
	padding: 10px;
	margin-top: 50px;
	background-color: #ADD8EC;

}
body {
  background-color: green;
}
</style>
</head>
<body>
	<h1 align="center">MEDICINE TABLE</h1>
	<table border="5" align="center" bgcolor="white" class="form-cover">
		<tr>
			<th>PRODUCT NAME</th>
			<th>PRICE</th>
			<th>IMAGE</th>
			<th>EXPIRY DATE</th>
			<th>CATEGORY</th>
			<th>COMPANY</th>
			<th>UPDATE</th>
			<th>DELETE</th>
		</tr>
		<?php
		$data_array=array("table"=>"product_tbl");
		$obj=new important;
		$rs=$obj->view_data($data_array);
		while($data=mysqli_fetch_array($rs)){
		?>
		<tr>
			<td><?php echo $data[1];?></td>
			<td><?php echo $data[2];?>/-</td>
			<td><img src="<?php echo $data[3];?>"></td>
			<td><?php echo $data[4];?></td>
			<td><?php echo $data[5];?></td>
			<td><?php echo $data[6];?></td>
			<td><a href="medupdate.php?id=<?php echo $data[0];?>">Update</a></td>
			<td><a href="meddelete.php?id=<?php echo $data[0];?>">Delete</a></td>

		</tr>
		<?php
		}
		?>
	</table>

</body>
</html>