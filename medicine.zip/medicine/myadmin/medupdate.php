<?php
include('head_class.php');
$obj=new important;
$data_array=array("table"=>"product_tbl");
array_push($data_array,$_GET);
$rs=$obj->view_data_id($data_array);
$data=mysqli_fetch_array($rs);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
body {
  background-color: yellow;
}
</style>
</head>
<body>
<form name="f1" method="post" action="medupdateAction.php">
	<input type="hidden" name="id" value="<?php echo $data[0];?>">
	<h2><table align="center">
		<tr>
			<td>PRODUCT NAME</td>
			<td>:</td>
			<td><input type="text" name="productname" value="<?php echo $data[1];?>"></td>
		</tr>
		<tr>
			<td>PRICE</td>
			<td>:</td>
			<td><input type="number" name="productprice" value="<?php echo $data[2];?>"></td>
		</tr>
		<tr>
			<td>IMAGE</td>
			<td>:</td>
			<td><input type="file" name="productimage" value="<?php echo $data[3];?>"></td>
		</tr>
		<tr>
			<td>EXPIRY DATE</td>
			<td>:</td>
			<td><input type="date" name="productexp_date" value="<?php echo $data[4];?>"></td>
		</tr>
		<tr>
			<td>CATEGORY</td>
			<td>:</td>
			<td><input type="text" name="category" value="<?php echo $data[5];?>"></td>
		</tr>
		<tr>
			<td>COMPANY</td>
			<td>:</td>
			<td><input type="text" name="company" value="<?php echo $data[6];?>"></td>
		</tr>
		<tr>
			<td class="label-txt"></td>
			<td colspan="3"><input type="submit" value="UPDATE"></td>
		</tr>
	</table></h2>
</form>
</body>
</html>