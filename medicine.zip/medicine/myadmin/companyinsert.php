<?php 
include('adminheader.php');
?>
<style>
body {
  background-color: lightblue;
}
</style>
<h1 align="center">Company insert</h1>
	<form name="f1" action="company_action.php" method="post">
		<table align="center">
			<tr>
				<td>COMPANY NAME</td>
				<td><input type="text" name="companyname"></td>
			</tr>
			<td class="label-txt"></td>
				<td colspan="2"><input type="submit" value="INSERT"></td>
			
		</table>
</body>
</html>