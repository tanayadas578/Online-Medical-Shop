<?php
include('head_class.php');
$obj=new important;
$data_array=array("table"=>"catagory_tbl");
array_push($data_array,$_GET);
$status=$obj->delete_data($data_array);
if($status==1){
?>
<script type="text/javascript">
	alert("Customer Data Deleted Successfully");
	window.location.href="catview.php";
</script>
<?php
}
else{
?>
<script type="text/javascript">
	alert("Error!");
	window.location.href="catview.php";
</script>
<?php
}

?>