<?php 
include('adminheader.php');
include('head_class.php');
?>

<!-- <div class="header">
  <h1>CARE AND CURE</h1>
   <p>This website created by me.</p> 
</div>

<div class="row">
  <div class="side">
    <h2>About Me</h2>
    <h5>Photo of me:</h5>
    <div class="fakeimg" style="height:200px;">Image</div>
    <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
    <h3>More Text</h3>
    <p>Lorem ipsum dolor sit ame.</p>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div>
  </div>
  <div class="main">
    <h2>TITLE HEADING</h2>
    <h5>Title description, sep 7, 2019</h5>
    <div class="fakeimg" style="height:200px;">Image</div>
    <p>Some text..</p>
    <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
    <br>
  </div>
</div> -->

<body>
  <h2 align="center">USER DATA</h2>
  <table border="1" align="center">
    <tr>
      <th>FirstName</th>
      <th>LastName</th>
      <th>Email</th>
      <th>Address</th>
    </tr>
    <?php
    $data_array=array("table"=>"user_tbl");
    $obj=new Important;
    $rs=$obj->view_data($data_array);
    while($data=mysqli_fetch_array($rs)){
    ?>
    <tr>
      <td><?php echo $data[1];?></td>
      <td><?php echo $data[2];?></td>
      <td><?php echo $data[3];?></td>
      <td><?php echo $data[4];?></td>
      </tr>
    <?php
    }
    ?>
  </table>
  <h1></h1>
  <div class="footer">
  <h2>Insert from navber.</h2>
</div>
  <p align="center">LICENSE : MIT License for website</p>
  <h2 align="center"><img src="image/CPY.png" width="10%"></h2>

<P>Copyright (c) 2019 Akshay Kashyap

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
</P>

<div class="footer">
  <h2>this website maintain by care and cure company</h2>
</div>

</body>
</html>