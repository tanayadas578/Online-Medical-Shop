<?php
session_start();
include('head_class.php');
$obj=new Important;
$data=array("table"=>"admin_tbl");
array_push($data,$_POST);
$n=$obj->login_check($data);
$rs=mysqli_fetch_array($n);
if($rs){
	$_SESSION['admin']=$_POST['adminuser'];
	$_SESSION['is_login']="true";
?>
	<script type="text/javascript">
		alert("Login Successfull");
		window.location.href='design.php';
	</script>
<?php
}
else{
	?>
	<script type="text/javascript">
		alert("Invalid Username or Password");
		window.location.href='index.php';
	</script>
<?php
}
?>