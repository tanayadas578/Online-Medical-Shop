<?php 
include('adminheader.php');
?>
<style>
body {
  background-color: lightblue;
}
</style>
<h1 align="center">Catagory insert</h1>
	<form name="f1" action="catagory_action.php" method="post">
		<table align="center">
			<tr>
				<td>CATAGORY TYPE</td>
				<td><input type="text" name="catagorytype"></td>
			</tr>
			<td class="label-txt"></td>
				<td colspan="2"><input type="submit" value="INSERT"></td>
		</table>
</body>
</html>