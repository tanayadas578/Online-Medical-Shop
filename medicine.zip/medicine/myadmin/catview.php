<?php 
include('adminheader.php');
?>
<?php include('head_class.php');?>
<!DOCTYPE html>
<html>
<head>

<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->

<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script> -->

	<title></title>
	<style>
.form-cover{
	margin: 10;
	width: 50%;
	border: 10px;
	border-radius: 10px;
	padding: 10px;
	margin-top: 50px;
	background-color: #ADD8EC;

}

body {
  background-color: green;
}
</style>
</head>
<body>
	<div>
	<h1 align="center">CATAGORY TABLE</h1>
	<table border="5" align="center" bgcolor="white" class="form-cover">
		<tr>
			<th>CATEGORY</th>
			<th>UPDATE</th>
			<th>DELETE</th>
		</tr>
		<?php
		$data_array=array("table"=>"catagory_tbl");
		$obj=new important;
		$rs=$obj->view_data($data_array);
		while($data=mysqli_fetch_array($rs)){
		?>
		<tr>
			<td><?php echo $data[1];?></td>
			<td><a href="catupdate.php?id=<?php echo $data[0];?>">Update</a></td>
			<td><a href="catdelete.php?id=<?php echo $data[0];?>">Delete</a></td>

		</tr>
		<?php
		}
		?>
	</table>
</div>

</body>
</html>