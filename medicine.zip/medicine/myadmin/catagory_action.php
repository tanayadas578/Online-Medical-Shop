 <?php
include('head_class.php');
$data_array=array("table"=>"catagory_tbl");
array_push($data_array,$_POST);
$obj=new Important;
$i=$obj->insert_data($data_array);
if($i==1){
?>
<script type="text/javascript">
	alert("Data Insert Successfully");
	window.location.href="catview.php";
</script>
<?php
}
else{
?>
<script type="text/javascript">
	alert("Error!");
	window.location.href="catagoryinsert.php";
</script>
<?php
}

?>