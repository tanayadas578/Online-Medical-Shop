<?php 
include('adminheader.php');
include('head_class.php')		
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
body {
  background-color: lightblue;
}
</style>
</head>
<body>

<h1 align="center"><font color="black">Insert Medicine</h1></font>
	<form name="f1" action="medicine_action.php" method="post">
		<table align="center">

			<tr>
				<td>PRODUCT NAME</td>
				<td><input type="text" name="productname" class="form-control"></td>
			</tr>
			<tr>
				<td>PRODUCT PRICE</td>
				<td><input type="text" name="productprice" class="form-control"></td>
			</tr>
			<tr>
				<td>IMAGE</td>
				<td><input type="file" name="productimage" class="form-control"></td>
			</tr>
			<tr>
				<td>EXPIRY DATE</td>
				<td><input type="date" name="productexp_date" class="form-control"></td>
			</tr>
			<tr>
				<td>CATEGORY</td>
				<!-- <td><input type="text" name="category" class="form-control"></td> -->
				<td>
					<?php
		$data_array=array("table"=>"catagory_tbl");
		$obj=new important;
		$rs=$obj->view_data($data_array);?>
		<select name="catagory"><?php
		while($data=mysqli_fetch_array($rs)){
		?>
					
						<option value="<?php echo $data[0];?>"><?php echo $data[1];?></option>
					
					<?php
		}
		?></select>
				</td>
			</tr>

			<tr>
				<td>COMPANY</td>
				<!-- <td><input type="text" name="company" class="form-control"></td> -->
				<td>
					<?php
		$data_array=array("table"=>"company_tbl");
		$obj=new important;
		$rs=$obj->view_data($data_array);?>
		<select name="company"><?php
		while($data=mysqli_fetch_array($rs)){
		?>
					
						<option value="<?php echo $data[0];?>"><?php echo $data[1];?></option>
					
					<?php
		}
		?></select>
				</td>
			</tr>
			<tr>
				<td class="label-txt"></td>
			<td colspan="4"><input type="submit" value="INSERT" class="btn-success"></td>
			</tr>
		</table>
	</form>
	</body>
</html>