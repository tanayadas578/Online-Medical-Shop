<?php
include('head_class.php');
$obj=new important;
$data_array=array("table"=>"company_tbl");
array_push($data_array,$_GET);
$rs=$obj->view_data_id($data_array);
$data=mysqli_fetch_array($rs);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
body {
  background-color: yellow;
}
</style>
</head>
<body>
<form name="f1" method="post" action="comupdateAction.php">
	<input type="hidden" name="id" value="<?php echo $data[0];?>">
	<table align="center">
		<tr>
		<td><h1>COMPANY</h1></td>
			<td>:</td>
			<td><input type="companyname" name="companyname" value="<?php echo $data[1];?>"></td>
		</tr>
		<tr>
			<td class="label-txt"></td>
			<td colspan="3"><input type="submit" value="UPDATE"></td>
		</tr>
	</table>
</form>
</body>
</html>