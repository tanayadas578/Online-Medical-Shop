<?php 
include('header.php');
?>

<div class="header">
  <h1>CARE OVER CURE</h1>
  <p>This website created by group " C "</p>
</div>

<div class="row">
  <div class="side">
    <h2>Photo of me:</h2>
    <p></p>
    <div class="fakeimg" style="height:200px;"></div>
    <h2>This company provides serves over 10 years.</h2>
    <h1><font color="red">SCHEDULE 'H' DRUG</font></h1>
  </div>

  <div class="main">
    <h2>Medicine Helpers</h2>
    <div class="fakeimg1" style="height:200px;"></div>
    <h4>Title Description Upload On : September 7, 2019</h4>
    <P>AFTER BUYING PLEASE KEEP ALL MEDICINE IN A COOL AND DRY PLACE</P>
    <h3><font color="red">WARNING : TO BE SOLD BY RETAIL ON THE PRESCRIPTION OF A REGISTERED MEDICAL PRACTITIONER ONLY.</font></h3>
    <br>
  </div>
</div>

<div class="row">
  <div class="column">
    <img src="image/Baby.jpg" style="width:50%">
  </div>
  <div class="column">
    <img src="image/Vitamin.jpg" style="width:50%">
    <h4>This is demo, For buy please go 'medicine & cart' part</h4>
  </div>
  <div class="column">
    <img src="image/powder.jpg" style="width:50%">
  </div>
</div>

<div class="footer">
  <h2>THANK YOU </h2>
</div>

</body>
</html>