<?php
 class Connect{
 	protected $con;
 	function __construct(){
 		ob_start();
 		$this->con=mysqli_connect("localhost","root","");
 		mysqli_select_db($this->con,"project");
 		
 	}
 }
 class Important extends Connect{
 	private $table_name;
 	/*Function name=insert_data
 	arguement list=array
 	return type=integer
 	created by=AS360
 	date=
 	*/

 	public function insert_data($data_array){
 		$this->table_name=$data_array['table'];
 	  //print_r($data_array[0]);
 		$count=count($data_array[0]);
 		$i=1;
 		$sql="insert into ".$this->table_name."(";
 		$sql1="values(";
 		foreach($data_array[0] as $key=>$value){
 			if($i==$count){
 				$sql=$sql.$key;
 				$sql1=$sql1."'".$value."'";
 			}
 			else{
 				$sql=$sql.$key.",";
 				$sql1=$sql1."'".$value."',";
 			}
 			$i++;
 		}
 		$sql=$sql.") ".$sql1.")";
 		//echo $sql;die();
 		return mysqli_query($this->con,$sql);
 	
 	}
 	/*End of function insert_data*/
 	// /*function name:view_data*/
 	public function view_data($data_array){
 		$this->table_name=$data_array['table'];
 		$sql="select * from ".$this->table_name;
 		$rs=mysqli_query($this->con,$sql);
 		return $rs;
 	}
 	/*end of function*/
 	/*function name:view_data_id*/
 	public function view_data_id($data){
 		$this->table_name=$data['table'];
 		$sql="select * from ".$this->table_name." where ";
 		foreach($data[0] as $key=>$value){
 			$sql=$sql.$key."='".$value."'";
 		}
 		$rs=mysqli_query($this->con,$sql);
 		return $rs;
 	}
 	/*end of function*/
//select c.*,p.*,com.* from catagory_tbl as c,product_tbl as p,company_tbl as com where c.id=p.catagory and com.id=p.company***********
//view medicine
 	public function view_medicine_data(){
 		$sql="select c.*,p.*,com.* from catagory_tbl as c,product_tbl as p,company_tbl as com where c.id=p.catagory and com.id=p.company";
 		return mysqli_query($this->con,$sql);
 	}


 	/*Update data function*/
 	public function update_data($data){
 		$this->table_name=$data['table'];
 		$count=count($data[0]);
 		$i=1;
 		$sql="update ".$this->table_name." set ";
 		$sql1="where ";
 		foreach($data[0] as $key=>$value){
 			if($i==1){
 				$sql1=$sql1.$key."='".$value."'";
 			}
 			elseif($i==$count){
 				$sql=$sql.$key."='".$value."' ";
 			}
 			else{
 				$sql=$sql.$key."='".$value."',";
 			}
 			$i++;
 		}
 		$sql=$sql.$sql1;
 		return mysqli_query($this->con,$sql);
 	}
 	/*end of function*/
 	// delete_data function
 	public function delete_data($data){
 		$this->table_name=$data['table'];
 		$sql="delete from ".$this->table_name." where ";
 		foreach($data[0] as $key=>$value){
 			$sql=$sql.$key."='".$value."'";
 		}
 		return mysqli_query($this->con,$sql);
 	}
 	/*end of function*/

 	//file data save//
 	public function file_data_save($data_Array){
 		$ext=strstr($data_Array[1]['image']['name'],".");

		$img1="pics/".rand(00000,99999)."_".microtime(TRUE).$ext;

		if( $ext==".jpg" || $ext==".png" || $ext==".jpeg")
		{
			if($data_Array[1]['image']['size']<1000000)
			{
				if(move_uploaded_file($data_Array[1]['image'][' tmp_name'],$img1))
				{
				$path=array("image"=>$img1);
				$data_save=array("table"=>$data_Array['table']);
				$data=array_merge($data_Array[0],$path);
				array_push($data_save,$data);
				print_r($data_save);die();
				return $this->insert_data($data_save);

				}
				else
				{
				return "Please select another file";
				}
			}
			else
			{
				return "Please choose right size";
			}

		}
		else
		{
			return "Please choose right format file";
		}

 	}

 	//end of function//
 	//login check//
 	public function login_check($data){
 		$this->table_name=$data['table'];
 		$sql="select id from ".$this->table_name." where email='".$data[0]['email']."' and password='".$data[0]['password']."'";
 		//echo $sql;die();
 		return mysqli_query($this->con,$sql);
 	}
 }
?>