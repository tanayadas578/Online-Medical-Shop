<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
  
.con {
  background-color: green;
}
.con1 {
  background-color: #ff85d5;
}
.con2 {
  background-color: lightgreen;
}
.con3 {
  background-color: #ff5c33;
}

.con4 {
  background-color: yellow;
}

</style>
</head>
<body>

<div align="center" class="w3-container">
  <h1>Know much more about us !</h1>
</div>

<div class="con4">
  <h2><u>Details</u></h2>
  <h3><p>This company will issue by international medicale association. And trusted over 10 years also have upto 5000+ coustomars.</p></h3>
</div>

<div class="con">
  <h1><u>24 x 7</u></h1>
  <h2><p>This website is open for 24 x 7 times. Any time you feel sick you can visit our website.</p></h2>
</div>

<div class="con1">
  <h1><u>Location</u></h1>
  <h2><p>Medicine will only dealivered in " INDIA", " AUSTRALIA " and "USA"</p></h2>
</div>

<div class="con3">
  <h1><u>Checking of returns</u></h1>
  <h2><p>Please check product details and expairy date before buy, after buy return policy ends in 1 week.</p></h2>
</div>

<div class="con2">
  <h1><u>Dealivery</u></h1>
  <h2><p>Our immideate Dealivery sistem only limited in 2 kilometers arounds our stores.</p></h2>
  <h2><p>Others dealivery will reach aprox 1 or 2 days after from booking.</p></h2>
</div>

</body>
</html> 
